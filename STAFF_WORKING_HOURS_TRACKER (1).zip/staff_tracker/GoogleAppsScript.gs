/**
 * STAFF WORKING HOURS TRACKER — Google Apps Script
 *
 * SETUP INSTRUCTIONS:
 * 1. Open your Google Sheet
 * 2. Go to Extensions → Apps Script
 * 3. Delete any existing code and paste this entire script
 * 4. Click Save (disk icon)
 * 5. Click Deploy → New deployment
 * 6. Set type to "Web app"
 * 7. Set "Execute as" to "Me"
 * 8. Set "Who has access" to "Anyone"
 * 9. Click Deploy and authorize permissions
 * 10. Copy the Web App URL and paste it in the app's Manager tab
 *
 * AFTER UPDATING: Deploy → Manage deployments → Edit → New version → Deploy
 */

var HEADERS = [
  'ID', 'Date', 'Employee Name', 'Position', 'Department', 'Activity',
  'Description', 'Location', 'Start Time', 'End Time', 'Duration (hrs)',
  'Requested By', 'Status', 'Synced At'
];

var TAB_COLORS = ['#4285F4','#EA4335','#FBBC04','#34A853','#FF6D00','#7B1FA2','#0097A7','#E91E63'];

function getOrCreateSheet(ss, name) {
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    var idx = Math.abs(name.split('').reduce(function(a,c){ return a+c.charCodeAt(0); },0)) % TAB_COLORS.length;
    sheet.setTabColor(TAB_COLORS[idx]);
  }
  return sheet;
}

function ensureHeaders(sheet) {
  if (sheet.getLastRow() === 0) {
    var range = sheet.getRange(1, 1, 1, HEADERS.length);
    range.setValues([HEADERS]);
    range.setBackground('#14532d');
    range.setFontColor('#ffffff');
    range.setFontWeight('bold');
    range.setFontSize(11);
    sheet.setFrozenRows(1);
  }
}

function rowToArray(row) {
  return [
    row.id || '',
    row.date || '',
    row.employeeName || '',
    row.position || '',
    row.department || '',
    row.activity || '',
    row.description || '',
    row.location || '',
    row.startTime || '',
    row.endTime || '',
    row.duration || '',
    row.requestedBy || '',
    row.status || '',
    row.syncedAt || new Date().toISOString()
  ];
}

function rebuildAllStaff(ss) {
  var summary = getOrCreateSheet(ss, 'All Staff');
  summary.setTabColor('#14532d');
  ensureHeaders(summary);

  var allRows = [];
  ss.getSheets().forEach(function(s) {
    if (s.getName() === 'All Staff') return;
    var last = s.getLastRow();
    if (last > 1) {
      var data = s.getRange(2, 1, last - 1, HEADERS.length).getValues();
      data.forEach(function(r) { if (r[0]) allRows.push(r); });
    }
  });

  allRows.sort(function(a, b) { return String(b[1]).localeCompare(String(a[1])); });

  var last = summary.getLastRow();
  if (last > 1) summary.deleteRows(2, last - 1);
  if (allRows.length > 0) {
    summary.getRange(2, 1, allRows.length, HEADERS.length).setValues(allRows);
  }
  summary.autoResizeColumns(1, HEADERS.length);
}

function processData(data) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var rows = data.rows || [];
  var empName = (data.employeeName || data.sheetName || 'Unknown').trim();

  var sheet = getOrCreateSheet(ss, empName);
  ensureHeaders(sheet);

  // Clear and rewrite
  var last = sheet.getLastRow();
  if (last > 1) sheet.deleteRows(2, last - 1);

  if (rows.length > 0) {
    var rowArrays = rows.map(rowToArray);
    sheet.getRange(2, 1, rowArrays.length, HEADERS.length).setValues(rowArrays);
  }
  sheet.autoResizeColumns(1, HEADERS.length);

  rebuildAllStaff(ss);

  return { success: true, employee: empName, synced: rows.length };
}

function doPost(e) {
  try {
    var data;

    // Try reading from FormData first (multipart/form-data)
    if (e.parameters && e.parameters.payload) {
      data = JSON.parse(e.parameters.payload[0]);
    }
    // Fallback: read raw post body (text/plain or application/json)
    else if (e.postData && e.postData.contents) {
      data = JSON.parse(e.postData.contents);
    }
    else {
      throw new Error('No data received');
    }

    var result = processData(data);

    return ContentService
      .createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);

  } catch(err) {
    var debugInfo = {
      success: false,
      error: err.message,
      hasParameters: !!e.parameters,
      hasPostData: !!(e.postData),
      postDataType: e.postData ? e.postData.type : 'none',
      postDataLength: e.postData ? e.postData.contents.length : 0
    };
    return ContentService
      .createTextOutput(JSON.stringify(debugInfo))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  return ContentService
    .createTextOutput(JSON.stringify({ success: true, message: 'Staff Hours Tracker is running', headers: HEADERS }))
    .setMimeType(ContentService.MimeType.JSON);
}
